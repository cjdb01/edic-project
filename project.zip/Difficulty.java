// do i want this like so? or as part of the generator
public enum Difficulty {
	KIDS, EASY, MEDIUM, HARD, EXPERT;
}
